// Organize and extract code from RAW_PROJECT_DRAFT.txt
