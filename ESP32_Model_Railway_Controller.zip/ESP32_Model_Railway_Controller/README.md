# ESP32 Model Railway Track Controller

This repository contains the AI-generated project draft shared in the chat.

## Structure

- ESP32_Model_Railway_Controller.ino
- config.h
- track_control.h
- web_interface.h
- data/
  - index.html
  - style.css
  - script.js

## Note

The original pasted content was not fully structured source code. The complete draft has been preserved in `RAW_PROJECT_DRAFT.txt` for cleanup and further development before compiling.
